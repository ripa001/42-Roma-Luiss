#!/usr/bin/env bash

source fct.sh && main $*
