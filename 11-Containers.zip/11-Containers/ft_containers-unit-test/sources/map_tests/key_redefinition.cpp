#include "../system/system_methods.ipp"
#include "__service.ipp"

int main() {
    _map<int, int>::iterator it;

    it->first = 1;

    return (0);
}