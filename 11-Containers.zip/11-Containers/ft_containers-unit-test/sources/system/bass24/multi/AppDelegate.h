/*
	BASS multiple output example
	Copyright (c) 2001-2021 Un4seen Developments Ltd.
*/

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@end

